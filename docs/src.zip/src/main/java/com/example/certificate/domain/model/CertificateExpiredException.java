package com.example.certificate.domain.model;

public class CertificateExpiredException extends RuntimeException {
    public CertificateExpiredException(String message) {
        super(message);
    }
}