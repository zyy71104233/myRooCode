package com.example.certificate.domain.model;

import java.time.LocalDate;

public class Certificate {
    private final String id;
    private final CertificateContent content;
    private CertificateStatus status;
    private final LocalDate issueDate;
    private final LocalDate expiryDate;

    public Certificate(String id, CertificateContent content, LocalDate issueDate, LocalDate expiryDate) {
        this.id = id;
        this.content = content;
        this.status = CertificateStatus.CREATED;
        this.issueDate = issueDate;
        this.expiryDate = expiryDate;
    }

    public void deploy() {
        if (isExpired()) {
            throw new CertificateExpiredException("Cannot deploy expired certificate");
        }
        this.status = CertificateStatus.DEPLOYED;
    }

    public boolean isExpired() {
        return LocalDate.now().isAfter(expiryDate);
    }

    // Getters
    public String getId() { return id; }
    public CertificateContent getContent() { return content; }
    public CertificateStatus getStatus() { return status; }
    public LocalDate getIssueDate() { return issueDate; }
    public LocalDate getExpiryDate() { return expiryDate; }
}