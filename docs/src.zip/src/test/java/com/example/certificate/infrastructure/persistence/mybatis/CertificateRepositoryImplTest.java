package com.example.certificate.infrastructure.persistence.mybatis;

import com.example.certificate.domain.model.Certificate;
import com.example.certificate.domain.model.CertificateContent;
import com.example.certificate.domain.model.CertificateStatus;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

import org.springframework.test.context.ActiveProfiles;
import com.example.certificate.TestConfig;
import org.springframework.context.annotation.Import;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestConfig.class)
@ActiveProfiles("test")
class CertificateRepositoryImplTest {

    @Autowired
    private CertificateRepositoryImpl repository;

    @Test
    void shouldSaveAndRetrieveCertificate() {
        Certificate certificate = new Certificate(
            "test-id",
            new CertificateContent("public-key", "private-key"),
            LocalDate.now(),
            LocalDate.now().plusYears(1)
        );

        repository.save(certificate);
        Certificate found = repository.findById("test-id");

        assertNotNull(found);
        assertEquals(certificate.getId(), found.getId());
        assertEquals(CertificateStatus.CREATED, found.getStatus());
    }

    @Test
    void shouldUpdateCertificate() {
        Certificate certificate = new Certificate(
            "test-id",
            new CertificateContent("public-key", "private-key"),
            LocalDate.now(),
            LocalDate.now().plusYears(1)
        );
        repository.save(certificate);

        certificate.deploy();
        repository.save(certificate);

        Certificate found = repository.findById("test-id");
        assertEquals(CertificateStatus.DEPLOYED, found.getStatus());
    }

    @Test
    void shouldDeleteCertificate() {
        Certificate certificate = new Certificate(
            "test-id",
            new CertificateContent("public-key", "private-key"),
            LocalDate.now(),
            LocalDate.now().plusYears(1)
        );
        repository.save(certificate);
        
        repository.delete("test-id");
        assertNull(repository.findById("test-id"));
    }
}