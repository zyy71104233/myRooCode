package com.example.certificate.domain.model;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class CertificateTest {
    private final LocalDate today = LocalDate.now();
    private final LocalDate tomorrow = today.plusDays(1);
    private final LocalDate yesterday = today.minusDays(1);
    private final CertificateContent validContent = new CertificateContent("publicKey", "privateKey");

    @Test
    void should_allow_deploy_when_active() {
        Certificate cert = new Certificate("id1", validContent, today, tomorrow);
        cert.deploy();
        assertEquals(CertificateStatus.DEPLOYED, cert.getStatus());
    }

    @Test
    void should_throw_when_deploy_expired() {
        Certificate cert = new Certificate("id2", validContent, yesterday, yesterday);
        assertThrows(CertificateExpiredException.class, cert::deploy);
    }

    @Test
    void should_return_true_when_expired() {
        Certificate cert = new Certificate("id3", validContent, yesterday, yesterday);
        assertTrue(cert.isExpired());
    }

    @Test
    void should_return_false_when_not_expired() {
        Certificate cert = new Certificate("id4", validContent, today, tomorrow);
        assertFalse(cert.isExpired());
    }
}