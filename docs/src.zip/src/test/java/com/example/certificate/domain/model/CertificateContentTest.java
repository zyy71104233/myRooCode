package com.example.certificate.domain.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CertificateContentTest {
    @Test
    void should_throw_when_public_key_invalid() {
        assertThrows(IllegalArgumentException.class, () -> {
            new CertificateContent(null, "valid-private-key");
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new CertificateContent("", "valid-private-key");
        });
    }

    @Test
    void should_throw_when_private_key_invalid() {
        assertThrows(IllegalArgumentException.class, () -> {
            new CertificateContent("valid-public-key", null);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new CertificateContent("valid-public-key", "");
        });
    }

    @Test
    void should_create_when_keys_valid() {
        String publicKey = "valid-public-key";
        String privateKey = "valid-private-key";
        
        CertificateContent content = new CertificateContent(publicKey, privateKey);
        
        assertEquals(publicKey, content.getPublicKey());
        assertEquals(privateKey, content.getPrivateKey());
    }

    @Test
    void should_be_equal_when_same_keys() {
        CertificateContent content1 = new CertificateContent("key1", "key2");
        CertificateContent content2 = new CertificateContent("key1", "key2");
        
        assertEquals(content1, content2);
        assertEquals(content1.hashCode(), content2.hashCode());
    }

    @Test
    void should_not_be_equal_when_different_keys() {
        CertificateContent content1 = new CertificateContent("key1", "key2");
        CertificateContent content2 = new CertificateContent("key1", "key3");
        
        assertNotEquals(content1, content2);
    }
}