package com.example.certificate.domain.model;

import java.util.Objects;

public class CertificateContent {
    private final String publicKey;
    private final String privateKey;

    public CertificateContent(String publicKey, String privateKey) {
        validateKeys(publicKey, privateKey);
        this.publicKey = publicKey;
        this.privateKey = privateKey;
    }

    private void validateKeys(String publicKey, String privateKey) {
        if (publicKey == null || publicKey.trim().isEmpty()) {
            throw new IllegalArgumentException("Public key cannot be null or empty");
        }
        if (privateKey == null || privateKey.trim().isEmpty()) {
            throw new IllegalArgumentException("Private key cannot be null or empty");
        }
    }

    public String getPublicKey() {
        return publicKey;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CertificateContent that = (CertificateContent) o;
        return publicKey.equals(that.publicKey) && 
               privateKey.equals(that.privateKey);
    }

    @Override
    public int hashCode() {
        return Objects.hash(publicKey, privateKey);
    }
}