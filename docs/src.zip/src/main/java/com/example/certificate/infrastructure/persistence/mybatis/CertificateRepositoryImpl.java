package com.example.certificate.infrastructure.persistence.mybatis;

import com.example.certificate.domain.model.Certificate;
import com.example.certificate.domain.repository.CertificateRepository;
import com.example.certificate.infrastructure.persistence.mybatis.mapper.CertificateMapper;
import org.springframework.stereotype.Repository;

@Repository
public class CertificateRepositoryImpl implements CertificateRepository {

    private final CertificateMapper certificateMapper;

    public CertificateRepositoryImpl(CertificateMapper certificateMapper) {
        this.certificateMapper = certificateMapper;
    }

    @Override
    public Certificate findById(String id) {
        return certificateMapper.selectById(id);
    }

    @Override
    public void save(Certificate certificate) {
        Certificate existing = certificateMapper.selectById(certificate.getId());
        if (existing == null) {
            certificateMapper.insert(certificate);
        } else {
            certificateMapper.update(certificate);
        }
    }

    @Override
    public void update(Certificate certificate) {
        certificateMapper.update(certificate);
    }

    @Override
    public void delete(String id) {
        certificateMapper.delete(id);
    }
}