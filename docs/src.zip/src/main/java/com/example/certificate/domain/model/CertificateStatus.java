package com.example.certificate.domain.model;

public enum CertificateStatus {
    CREATED,    // 已创建
    ACTIVE,     // 已激活
    DEPLOYED,   // 已部署
    EXPIRED,    // 已过期
    REVOKED     // 已撤销
}