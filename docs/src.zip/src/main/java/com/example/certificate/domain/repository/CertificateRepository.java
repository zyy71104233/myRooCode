package com.example.certificate.domain.repository;

import com.example.certificate.domain.model.Certificate;

public interface CertificateRepository {
    Certificate findById(String id);
    void save(Certificate certificate);
    void update(Certificate certificate);
    void delete(String id);
}