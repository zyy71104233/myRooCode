package com.example.certificate;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@MapperScan("com.example.certificate.infrastructure.persistence.mybatis.mapper")
@ImportAutoConfiguration(DataSourceAutoConfiguration.class)
@Import({
    com.example.certificate.infrastructure.persistence.mybatis.CertificateRepositoryImpl.class
})
public class TestConfig {
}