package com.example.certificate.infrastructure.persistence.mybatis.mapper;

import com.example.certificate.domain.model.Certificate;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CertificateMapper {
    void insert(Certificate certificate);
    Certificate selectById(String id);
    void update(Certificate certificate);
    void delete(String id);
}